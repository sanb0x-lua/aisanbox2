--Weapon//Update: 0x3CB194
--ACKA01=gg.getRangesList('libil2cpp.so')[3].start
--APEX=nil  APEX={}
--APEX[1]={}
--APEX[1].address=ACKA01+0x3CB194+0
--APEX[1].value='D2800020h'
--APEX[1].flags=4
--APEX[2]={}
--APEX[2].address=ACKA01+0x3CB194+4
--APEX[2].value='D65F03C0h'
--APEX[2].flags=4
--gg.setValues(APEX)

--PlayerWeaponManager//Update: 0x3A3658
ACKA01=gg.getRangesList('libil2cpp.so')[3].start
APEX=nil  APEX={}
APEX[1]={}
APEX[1].address=ACKA01+0x3A3658+0
APEX[1].value='D2800020h'
APEX[1].flags=4
APEX[2]={}
APEX[2].address=ACKA01+0x3A3658+4
APEX[2].value='D65F03C0h'
APEX[2].flags=4
gg.setValues(APEX)

--PlayerWeaponManager//Update: 0x39D390
ACKA01=gg.getRangesList('libil2cpp.so')[3].start
APEX=nil  APEX={}
APEX[1]={}
APEX[1].address=ACKA01+0x39D390+0
APEX[1].value='D2800020h'
APEX[1].flags=4
APEX[2]={}
APEX[2].address=ACKA01+0x39D390+4
APEX[2].value='D65F03C0h'
APEX[2].flags=4
gg.setValues(APEX)